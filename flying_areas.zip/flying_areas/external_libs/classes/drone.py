class Drone:
    """
        Classe qui permet de décrire un drone

    """
    def __init__(self):
        pass

