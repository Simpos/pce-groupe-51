from dataclasses import dataclass, field
from qgis.core import QgsPointXY, QgsGeometry
from qgis.PyQt.QtGui import QColor


@dataclass
class Zone:
    """Zone décrite par une liste de sommets (anneau extérieur)."""
    points: list[QgsPointXY] = field(default_factory=list)
    color: QColor = field(default_factory=lambda:QColor("red"))

    def add_point(self, p: QgsPointXY) -> None:
        self.points.append(p)

    def geometrie(self) -> QgsGeometry | None:
        """Renvoie le polygone, ou None s'il n'a pas assez de sommets."""
        if len(self.points) < 3:
            return None
        geom = QgsGeometry.fromPolygonXY([self.points])
        return geom

    def is_valid(self) -> bool:
        geom = self.geometrie()
        return geom is not None and geom.isGeosValid()

    def intersect(self, other: "Zone") -> bool:
        a, b = self.geometrie(), other.geometrie()
        return a is not None and b is not None and a.intersects(b)

    def __repr__(self) -> str:
        coords = ", ".join(f"({p.x():.2f}, {p.y():.2f})" for p in self.points)
        return f"Zone([{coords}])"
